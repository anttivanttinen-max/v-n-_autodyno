# Kaivokympit IMAP-välikerros

Pieni read-only IMAP-sovellus, joka hakee sähköposteja ja poimii työkohteita puhelimella käytettävään näkymään.

## Mitä se tekee
- yhdistää IMAP SSL:llä palvelimeen `mail.kaivokympit.fi:993`
- hakee INBOX-viestejä valitulta ajalta
- ei poista, siirrä tai tarkoituksella merkitse viestejä luetuiksi
- yrittää tunnistaa nimen, osoitteen, puhelimen ja sähköpostin
- muodostaa tekstikoosteen, jonka voi kopioida ChatGPT:hen reitin järjestämistä varten

## Käynnistys tietokoneella / palvelimella
1. Asenna Node.js 20+
2. Kopioi `.env.example` nimelle `.env`
3. Laita `IMAP_PASS`-kohtaan sähköpostin salasana
4. Aja:
   npm install
   npm start
5. Avaa selaimessa `http://localhost:3000`

## Julkaisu
Sovellus tarvitsee palvelimen, joka pystyy avaamaan ulospäin TCP-yhteyden IMAP-porttiin 993.
Render, Railway, Fly.io tai oma VPS sopivat paremmin kuin tavallinen staattinen Netlify-sivu.

Palvelun ympäristömuuttujiin:
- IMAP_HOST=mail.kaivokympit.fi
- IMAP_PORT=993
- IMAP_USER=huolto@kaivokympit.fi
- IMAP_PASS=<salasana>
- PORT yleensä palvelu asettaa itse

Älä laita oikeaa salasanaa GitHubiin tai lähetä sitä ChatGPT-keskusteluun.
