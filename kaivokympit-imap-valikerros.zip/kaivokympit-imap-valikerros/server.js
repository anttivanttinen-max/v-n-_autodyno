import 'dotenv/config';
import express from 'express';
import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

const PORT = process.env.PORT || 3000;
const IMAP_HOST = process.env.IMAP_HOST || 'mail.kaivokympit.fi';
const IMAP_PORT = Number(process.env.IMAP_PORT || 993);
const IMAP_USER = process.env.IMAP_USER;
const IMAP_PASS = process.env.IMAP_PASS;

if (!IMAP_USER || !IMAP_PASS) {
  console.warn('IMAP_USER tai IMAP_PASS puuttuu ympäristömuuttujista.');
}

function newClient() {
  return new ImapFlow({
    host: IMAP_HOST,
    port: IMAP_PORT,
    secure: true,
    auth: { user: IMAP_USER, pass: IMAP_PASS },
    logger: false
  });
}

function stripHtml(html = '') {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\s+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function extractFields(text) {
  const lines = text.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const joined = lines.join('\n');

  const phone = joined.match(/(?:\+358|0)\s?(?:4\d|50)\s?(?:\d[\s-]?){6,8}/)?.[0] || '';
  const email = joined.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || '';

  const postal = lines.find(line =>
    /\b\d{5}\b/.test(line) &&
    !/@/.test(line) &&
    line.length < 120
  ) || '';

  const address = lines.find(line =>
    /\b\d{1,4}\s*[A-Za-zÅÄÖåäö\- ]{2,}(?:tie|katu|kuja|polku|väylä|ranta|rinne|kaari|mäki|raitti|aukio)\b/i.test(line)
    || /\b[A-Za-zÅÄÖåäö\- ]{3,}\s+\d{1,4}[A-Za-z]?\b/.test(line)
  ) || '';

  const likelyName = lines.find(line =>
    line.length >= 3 &&
    line.length <= 70 &&
    !/@/.test(line) &&
    !/\d{3,}/.test(line) &&
    !/^(hei|moi|terve|yst\.|t\.|lähetetty|from:|to:|subject:)/i.test(line)
  ) || '';

  return { likelyName, address, postal, phone, email };
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, host: IMAP_HOST, port: IMAP_PORT, userConfigured: Boolean(IMAP_USER) });
});

app.get('/api/messages', async (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days || 14), 1), 90);
  const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 200);
  const unseenOnly = String(req.query.unseen || 'false') === 'true';

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const client = newClient();

  try {
    await client.connect();
    const lock = await client.getMailboxLock('INBOX');

    try {
      const search = { since };
      if (unseenOnly) search.seen = false;

      const uids = await client.search(search, { uid: true });
      const selected = uids.slice(-limit).reverse();

      const out = [];
      for (const uid of selected) {
        const msg = await client.fetchOne(uid, {
          uid: true,
          envelope: true,
          source: true,
          flags: true,
          internalDate: true
        }, { uid: true });

        if (!msg?.source) continue;

        const parsed = await simpleParser(msg.source);
        const text = (parsed.text || stripHtml(parsed.html || '') || '').trim();
        const preview = text.replace(/\s+/g, ' ').slice(0, 700);
        const fields = extractFields(text);

        out.push({
          uid: msg.uid,
          subject: parsed.subject || '(ei aihetta)',
          from: parsed.from?.text || '',
          date: parsed.date || msg.internalDate || null,
          seen: msg.flags?.has('\\Seen') || false,
          preview,
          text,
          fields
        });
      }

      res.json({ ok: true, count: out.length, messages: out });
    } finally {
      lock.release();
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({
      ok: false,
      error: 'IMAP-yhteys epäonnistui',
      detail: err?.message || String(err)
    });
  } finally {
    try { await client.logout(); } catch {}
  }
});

app.listen(PORT, () => {
  console.log(`Kaivokympit IMAP-välikerros: http://localhost:${PORT}`);
});
